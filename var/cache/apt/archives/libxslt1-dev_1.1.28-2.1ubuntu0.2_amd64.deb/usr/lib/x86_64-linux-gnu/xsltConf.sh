#
# Configuration file for using the xslt library
#
XSLT_LIBDIR="-L/usr/lib/x86_64-linux-gnu"
XSLT_LIBS="-lxslt  -lxml2 "
XSLT_INCLUDEDIR="-I/usr/include"
MODULE_VERSION="xslt-1.1.28"
