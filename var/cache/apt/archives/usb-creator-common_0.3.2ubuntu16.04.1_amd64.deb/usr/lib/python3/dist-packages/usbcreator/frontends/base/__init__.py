from usbcreator.frontends.base.frontend import Frontend
