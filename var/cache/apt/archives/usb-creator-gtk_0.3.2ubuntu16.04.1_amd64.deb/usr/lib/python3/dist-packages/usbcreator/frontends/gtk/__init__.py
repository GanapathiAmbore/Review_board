from usbcreator.frontends.gtk.frontend import GtkFrontend
